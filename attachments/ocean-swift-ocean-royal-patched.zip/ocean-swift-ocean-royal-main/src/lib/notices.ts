import type { LangCode } from "./languages.ts";

/**
 * Safety and honesty notices. Kept apart from messages.ts so they can be reviewed as a set.
 * English is the source of truth. Hindi and Kannada are drafts written by Claude and MUST be
 * reviewed by a native speaker (Kannada Localisation Specialist, E7) before farmer use.
 * Every other language falls back to English until reviewed translations exist.
 */
export const en = {
  photoConsentText: "Photos are sent to an outside AI service (xAI) so they can be read. Keep people’s faces out of the photo.",
  photoConsentCheck: "I understand my photo is sent to an outside AI service.",
  leafNotice: "This is only what the AI could see in the photo. It is not a diagnosis. A photo cannot reliably tell disease, nutrient shortage, pests and weather damage apart.",
  leafGuidance: "Do not spray or apply fertiliser because of this photo alone. Show the plant, or a clear photo, to your nearest Krishi Vigyan Kendra (KVK) or agriculture officer before treating.",
  leafUnusable: "The photo is too unclear to read. Take a close, well-lit photo of one leaf.",
  leafNoSigns: "No clear problem signs were visible in this photo. If the plant still looks unwell, ask your KVK or agriculture officer.",
  expertFallback: "The photo could not be analysed right now. Please ask your nearest KVK or agriculture officer. Do not treat the plant based on guesses.",
  demoBanner: "Demo example only. It is not about your plant or your field. Do not act on it.",
  soilNotRead: "The card could not be read. Please type the values from your card.",
  soilUnreadable: "Some values could not be read from the card: {fields}. Please type them from your card.",
  soilSampleNotSavable: "Example values only. They are not your soil and cannot be saved.",
  soilIncomplete: "Fill in every value with a sensible number before saving: {fields}.",
  soilTextureNote: "The Soil Health Card does not list soil texture. Choose it yourself.",
  placeholderShort: "Example figure, not verified",
  placeholderBanner: "These numbers use built-in example figures for yield, cost and price. They are not checked for your village and are not a forecast. Ask your KVK before deciding what to plant.",
  sign_yellowing_uniform: "Whole leaf turning yellow",
  sign_yellowing_between_veins: "Yellowing between the veins",
  sign_purple_red_tint: "Purple or red tint",
  sign_brown_or_dark_spots: "Brown or dark spots",
  sign_edge_scorch: "Leaf edges look scorched",
  sign_wilting_drooping: "Wilting or drooping",
  sign_chewed_holes: "Chewed holes",
  sign_curling_or_twisting: "Curling or twisting",
  sign_white_or_grey_coating: "White or grey coating",
  sign_fine_speckling: "Fine speckling",
  sign_none_visible: "No clear signs visible",
} as const;

export type NoticeKey = keyof typeof en;

const hi: Partial<Record<NoticeKey, string>> = {
  photoConsentText: "फ़ोटो पढ़ने के लिए उसे बाहरी AI सेवा (xAI) को भेजा जाता है। फ़ोटो में लोगों के चेहरे न आने दें।",
  photoConsentCheck: "मुझे पता है कि मेरी फ़ोटो बाहरी AI सेवा को भेजी जाती है।",
  leafNotice: "यह केवल वही है जो AI को फ़ोटो में दिखा, निदान नहीं। रोग, पोषक तत्वों की कमी, कीट और मौसम की मार को फ़ोटो से पक्के तौर पर अलग नहीं किया जा सकता।",
  leafGuidance: "केवल इस फ़ोटो के आधार पर छिड़काव या खाद न डालें। उपचार से पहले पौधा या साफ़ फ़ोटो नज़दीकी कृषि विज्ञान केंद्र (KVK) या कृषि अधिकारी को दिखाएँ।",
  leafUnusable: "फ़ोटो पढ़ने लायक साफ़ नहीं है। एक पत्ती की पास से, अच्छी रोशनी में फ़ोटो लें।",
  leafNoSigns: "इस फ़ोटो में समस्या के साफ़ लक्षण नहीं दिखे। पौधा फिर भी बीमार लगे तो KVK या कृषि अधिकारी से पूछें।",
  expertFallback: "अभी फ़ोटो का विश्लेषण नहीं हो सका। कृपया नज़दीकी KVK या कृषि अधिकारी से पूछें। अंदाज़े से पौधे का उपचार न करें।",
  demoBanner: "यह केवल नमूना उदाहरण है। इसका आपके पौधे या खेत से कोई संबंध नहीं। इस पर अमल न करें।",
  soilNotRead: "कार्ड पढ़ा नहीं जा सका। कृपया अपने कार्ड के मान टाइप करें।",
  soilUnreadable: "कार्ड से कुछ मान पढ़े नहीं जा सके: {fields}। कृपया कार्ड से टाइप करें।",
  soilSampleNotSavable: "ये केवल उदाहरण के मान हैं। ये आपकी मिट्टी के नहीं हैं और सहेजे नहीं जा सकते।",
  soilIncomplete: "सहेजने से पहले हर मान सही संख्या में भरें: {fields}।",
  soilTextureNote: "मृदा स्वास्थ्य कार्ड में मिट्टी की बनावट नहीं होती। इसे आप स्वयं चुनें।",
  placeholderShort: "नमूना आँकड़ा, जाँचा हुआ नहीं",
  placeholderBanner: "ये आँकड़े उपज, लागत और भाव के बने-बनाए नमूना आँकड़ों पर आधारित हैं। ये आपके गाँव के लिए जाँचे हुए नहीं हैं और पूर्वानुमान भी नहीं हैं। क्या बोना है, तय करने से पहले KVK से पूछें।",
  sign_yellowing_uniform: "पूरी पत्ती पीली",
  sign_yellowing_between_veins: "नसों के बीच पीलापन",
  sign_purple_red_tint: "बैंगनी या लाल आभा",
  sign_brown_or_dark_spots: "भूरे या काले धब्बे",
  sign_edge_scorch: "किनारे झुलसे हुए",
  sign_wilting_drooping: "मुरझाना या झुकना",
  sign_chewed_holes: "कुतरे हुए छेद",
  sign_curling_or_twisting: "मुड़ना या ऐंठना",
  sign_white_or_grey_coating: "सफ़ेद या स्लेटी परत",
  sign_fine_speckling: "बारीक चित्तियाँ",
  sign_none_visible: "कोई साफ़ लक्षण नहीं दिखा",
};

const kn: Partial<Record<NoticeKey, string>> = {
  photoConsentText: "ಫೋಟೋವನ್ನು ಓದಲು ಹೊರಗಿನ AI ಸೇವೆಗೆ (xAI) ಕಳುಹಿಸಲಾಗುತ್ತದೆ. ಜನರ ಮುಖಗಳು ಫೋಟೋದಲ್ಲಿ ಬರದಂತೆ ನೋಡಿಕೊಳ್ಳಿ.",
  photoConsentCheck: "ನನ್ನ ಫೋಟೋವನ್ನು ಹೊರಗಿನ AI ಸೇವೆಗೆ ಕಳುಹಿಸಲಾಗುತ್ತದೆ ಎಂದು ನನಗೆ ತಿಳಿದಿದೆ.",
  leafNotice: "ಇದು ಫೋಟೋದಲ್ಲಿ AI ಗೆ ಕಂಡದ್ದು ಮಾತ್ರ; ರೋಗ ನಿರ್ಣಯ ಅಲ್ಲ. ರೋಗ, ಪೋಷಕಾಂಶದ ಕೊರತೆ, ಕೀಟ ಮತ್ತು ಹವಾಮಾನದ ಹಾನಿಯನ್ನು ಫೋಟೋದಿಂದ ಖಚಿತವಾಗಿ ಬೇರ್ಪಡಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ.",
  leafGuidance: "ಈ ಫೋಟೋ ಆಧಾರದ ಮೇಲೆ ಮಾತ್ರ ಸಿಂಪಡಣೆ ಅಥವಾ ಗೊಬ್ಬರ ಹಾಕಬೇಡಿ. ಚಿಕಿತ್ಸೆ ಮಾಡುವ ಮೊದಲು ಗಿಡವನ್ನು ಅಥವಾ ಸ್ಪಷ್ಟ ಫೋಟೋವನ್ನು ಹತ್ತಿರದ ಕೃಷಿ ವಿಜ್ಞಾನ ಕೇಂದ್ರ (KVK) ಅಥವಾ ಕೃಷಿ ಅಧಿಕಾರಿಗೆ ತೋರಿಸಿ.",
  leafUnusable: "ಫೋಟೋ ಓದಲು ಸಾಕಷ್ಟು ಸ್ಪಷ್ಟವಾಗಿಲ್ಲ. ಒಂದು ಎಲೆಯ ಹತ್ತಿರದ, ಚೆನ್ನಾಗಿ ಬೆಳಕಿರುವ ಫೋಟೋ ತೆಗೆಯಿರಿ.",
  leafNoSigns: "ಈ ಫೋಟೋದಲ್ಲಿ ಸ್ಪಷ್ಟ ಸಮಸ್ಯೆಯ ಲಕ್ಷಣಗಳು ಕಾಣಲಿಲ್ಲ. ಗಿಡ ಇನ್ನೂ ಅಸ್ವಸ್ಥವಾಗಿ ಕಂಡರೆ KVK ಅಥವಾ ಕೃಷಿ ಅಧಿಕಾರಿಯನ್ನು ಕೇಳಿ.",
  expertFallback: "ಈಗ ಫೋಟೋವನ್ನು ವಿಶ್ಲೇಷಿಸಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ. ದಯವಿಟ್ಟು ಹತ್ತಿರದ KVK ಅಥವಾ ಕೃಷಿ ಅಧಿಕಾರಿಯನ್ನು ಕೇಳಿ. ಊಹೆಯ ಮೇಲೆ ಗಿಡಕ್ಕೆ ಚಿಕಿತ್ಸೆ ಮಾಡಬೇಡಿ.",
  demoBanner: "ಇದು ಕೇವಲ ಮಾದರಿ ಉದಾಹರಣೆ. ನಿಮ್ಮ ಗಿಡ ಅಥವಾ ಹೊಲಕ್ಕೆ ಸಂಬಂಧಿಸಿದ್ದಲ್ಲ. ಇದರ ಮೇಲೆ ಕ್ರಮ ತೆಗೆದುಕೊಳ್ಳಬೇಡಿ.",
  soilNotRead: "ಕಾರ್ಡ್ ಓದಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ. ನಿಮ್ಮ ಕಾರ್ಡ್‌ನಲ್ಲಿರುವ ಮೌಲ್ಯಗಳನ್ನು ಟೈಪ್ ಮಾಡಿ.",
  soilUnreadable: "ಕಾರ್ಡ್‌ನಿಂದ ಕೆಲವು ಮೌಲ್ಯಗಳನ್ನು ಓದಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ: {fields}. ದಯವಿಟ್ಟು ನಿಮ್ಮ ಕಾರ್ಡ್‌ನಿಂದ ಟೈಪ್ ಮಾಡಿ.",
  soilSampleNotSavable: "ಇವು ಕೇವಲ ಉದಾಹರಣೆ ಮೌಲ್ಯಗಳು. ಇವು ನಿಮ್ಮ ಮಣ್ಣಿನದಲ್ಲ, ಉಳಿಸಲಾಗುವುದಿಲ್ಲ.",
  soilIncomplete: "ಉಳಿಸುವ ಮೊದಲು ಪ್ರತಿ ಮೌಲ್ಯವನ್ನು ಸರಿಯಾದ ಸಂಖ್ಯೆಯಲ್ಲಿ ತುಂಬಿ: {fields}.",
  soilTextureNote: "ಮಣ್ಣು ಆರೋಗ್ಯ ಕಾರ್ಡ್‌ನಲ್ಲಿ ಮಣ್ಣಿನ ಸ್ವರೂಪ (ಟೆಕ್ಸ್ಚರ್) ಇರುವುದಿಲ್ಲ. ನೀವೇ ಆರಿಸಿ.",
  placeholderShort: "ಮಾದರಿ ಅಂಕಿ, ಪರಿಶೀಲಿತವಲ್ಲ",
  placeholderBanner: "ಈ ಸಂಖ್ಯೆಗಳು ಇಳುವರಿ, ವೆಚ್ಚ ಮತ್ತು ಬೆಲೆಗೆ ಅಂತರ್ನಿರ್ಮಿತ ಮಾದರಿ ಅಂಕಿಗಳನ್ನು ಬಳಸುತ್ತವೆ. ಇವು ನಿಮ್ಮ ಹಳ್ಳಿಗೆ ಪರಿಶೀಲಿತವಲ್ಲ, ಮುನ್ನೋಟವೂ ಅಲ್ಲ. ಏನು ಬಿತ್ತಬೇಕೆಂದು ನಿರ್ಧರಿಸುವ ಮೊದಲು KVK ಯನ್ನು ಕೇಳಿ.",
  sign_yellowing_uniform: "ಎಲೆ ಪೂರ್ತಿ ಹಳದಿಯಾಗುತ್ತಿದೆ",
  sign_yellowing_between_veins: "ನರಗಳ ನಡುವೆ ಹಳದಿ",
  sign_purple_red_tint: "ನೇರಳೆ ಅಥವಾ ಕೆಂಪು ಛಾಯೆ",
  sign_brown_or_dark_spots: "ಕಂದು ಅಥವಾ ಕಪ್ಪು ಚುಕ್ಕೆಗಳು",
  sign_edge_scorch: "ಎಲೆಯ ಅಂಚು ಸುಟ್ಟಂತೆ ಕಾಣುತ್ತದೆ",
  sign_wilting_drooping: "ಬಾಡುವುದು ಅಥವಾ ಜೋತು ಬೀಳುವುದು",
  sign_chewed_holes: "ತಿಂದಂತಹ ರಂಧ್ರಗಳು",
  sign_curling_or_twisting: "ಸುರುಳಿಯಾಗುವುದು ಅಥವಾ ತಿರುಚುವುದು",
  sign_white_or_grey_coating: "ಬಿಳಿ ಅಥವಾ ಬೂದು ಪದರ",
  sign_fine_speckling: "ಸೂಕ್ಷ್ಮ ಚುಕ್ಕೆಗಳು",
  sign_none_visible: "ಸ್ಪಷ್ಟ ಲಕ್ಷಣ ಕಾಣಲಿಲ್ಲ",
};

const BY_LANG: Partial<Record<string, Partial<Record<NoticeKey, string>>>> = { hi, kn };

export function notice(lang: LangCode | string, key: NoticeKey, vars?: Record<string, string>): string {
  const raw = BY_LANG[lang]?.[key] ?? en[key];
  return vars ? raw.replace(/\{(\w+)\}/g, (_, k: string) => vars[k] ?? "") : raw;
}

export function signLabel(lang: LangCode | string, sign: string): string {
  const key = `sign_${sign}` as NoticeKey;
  return key in en ? notice(lang, key) : sign;
}
